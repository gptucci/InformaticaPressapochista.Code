﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace FreshMvvmApp
{
	public partial class ContactListPage : BasePage
	{
		public ContactListPage ()
		{
			InitializeComponent ();
		}
	}
}

