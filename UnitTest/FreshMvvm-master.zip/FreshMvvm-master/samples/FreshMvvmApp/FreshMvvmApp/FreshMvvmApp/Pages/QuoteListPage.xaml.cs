﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace FreshMvvmApp
{
	public partial class QuoteListPage : BasePage
	{
		public QuoteListPage ()
		{
			InitializeComponent ();
		}
	}
}

