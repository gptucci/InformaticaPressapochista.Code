﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace FreshMvvmApp
{
	public partial class ModalPage : ContentPage
	{
		public ModalPage ()
		{
			InitializeComponent ();
		}
	}
}

