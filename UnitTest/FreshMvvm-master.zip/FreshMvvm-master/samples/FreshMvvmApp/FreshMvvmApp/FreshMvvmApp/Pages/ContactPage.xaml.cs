﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace FreshMvvmApp
{
	public partial class ContactPage : BasePage
	{
		public ContactPage ()
		{
			InitializeComponent ();
		}
	}
}

