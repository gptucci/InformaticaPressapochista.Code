﻿using System;

namespace FreshMvvm
{
    public static class Constants
    {
        public const string DefaultNavigationServiceName = "DefaultNavigationServiceName";
    }
}

