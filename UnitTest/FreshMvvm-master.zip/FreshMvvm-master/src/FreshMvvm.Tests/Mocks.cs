﻿using System;

namespace FreshMvvm.Tests
{
	public class Mocks
	{
		public Mocks ()
		{
		}
	}
}

