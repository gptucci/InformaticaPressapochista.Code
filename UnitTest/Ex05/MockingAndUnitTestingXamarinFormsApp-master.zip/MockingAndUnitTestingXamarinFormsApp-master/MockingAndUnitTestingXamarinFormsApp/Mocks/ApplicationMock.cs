﻿using Xamarin.Forms;

namespace Tests.Mocks
{
	public class ApplicationMock : Application
    {
		public ApplicationMock()
		{

		}
    }
}
