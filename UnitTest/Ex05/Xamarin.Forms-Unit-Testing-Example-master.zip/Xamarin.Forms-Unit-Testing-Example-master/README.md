# Xamarin.Forms-Unit-Testing-Example
This is a simple example of how to add unit tests to your Xamarin.Forms applications.
